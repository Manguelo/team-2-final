﻿Imports System.Data.SqlClient
Public Class frmMember
    Private Sub tsbRole_Click(sender As Object, e As EventArgs) Handles tsbRole.Click

    End Sub
End Class